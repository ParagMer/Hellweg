# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
import pymysql
from .config import *
from .items import *


class HellwegPipeline:
    def makedatabase(self, region):
        self.con = pymysql.connect(host=db_host, user=db_user, password=db_passwd)
        db_cursor = self.con.cursor()
        db_nam = f'hellweg_{region}'
        create_db = f"create database if not exists {db_nam} CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci"
        db_cursor.execute(create_db)
        self.con = pymysql.connect(host=db_host, user=db_user, password=db_passwd, database=db_nam, autocommit=True,use_unicode=True,charset="utf8")
        self.cursor = self.con.cursor()
        try:
            create_table = "create table if not exists " + db_input_sku + """(
                                                                                  `Id` int(11) NOT NULL AUTO_INCREMENT,
                                                                                  `Product_Url` varchar(555) DEFAULT NULL,
                                                                                  `Status` varchar(50) DEFAULT 'Pending',
                                                                                  PRIMARY KEY (`Id`)
                                                                                   ) ENGINE=InnoDB DEFAULT CHARSET=utf8 """
            self.cursor.execute(create_table)
        except Exception as e:
            print(f'Error in creating table {region} input table',e)

        try:
            create_table = "create table if not exists " + db_subcategory + """(
                                                                        `Id` int(11) NOT NULL AUTO_INCREMENT,
                                                                        `Category` varchar(500) DEFAULT NULL,
                                                                        `Category_URL` varchar(500) DEFAULT NULL,
                                                                        `SubCategory` mediumtext,
                                                                        `SubCategory_hex_dig` mediumtext,
                                                                        `SubCategoryURL` varchar(500) DEFAULT NULL,
                                                                        `SubsubCategory` varchar(500) DEFAULT NULL,
                                                                        `SubsubCategory_hex_dig` mediumtext,
                                                                        `SubsubCategoryURL` varchar(500) DEFAULT NULL,
                                                                        `Category_Node` varchar(500) DEFAULT NULL,
                                                                        `totalcount` int(11) DEFAULT NULL,
                                                                        `totalcount1` int(11) DEFAULT NULL,
                                                                        `Count` int(11) DEFAULT NULL,
                                                                        `lStatus` varchar(50) DEFAULT 'Pending',
                                                                        `Status` varchar(50) DEFAULT 'Pending',
                                                                        PRIMARY KEY (`Id`),
                                                                        KEY `NewIndex2` (`Status`),
                                                                        KEY `NewIndex3` (`SubCategoryURL`(255))
                                                                      )ENGINE = MYISAM"""
            self.cursor.execute(create_table)
        except Exception as e:
            print(f'Error in creating {region} subcategory table',e)

        try:
            create_table = "create table if not exists " + db_data_table + """(
                                                                        `Id` int(11) NOT NULL AUTO_INCREMENT,
                                                                        `ID1` int(11) DEFAULT NULL,
                                                                        `status` varchar(50) DEFAULT 'Pending',
                                                                        `status_PDP` varchar(50) DEFAULT 'Pending',
                                                                        `HTML_PL_Path` mediumtext,
                                                                        `HTML_PDP_Path` mediumtext,
                                                                        `Rank` varchar(500) DEFAULT NULL,
                                                                        `Category` varchar(500) DEFAULT NULL,
                                                                        `SubCategory` mediumtext,
                                                                        `SubsubCategory` varchar(500) DEFAULT NULL,
                                                                        `ean` varchar(50) DEFAULT NULL,
                                                                        `shop_domain` varchar(500) DEFAULT NULL,
                                                                        `store_selected` varchar(100) DEFAULT NULL,
                                                                        `article_number` varchar(100) DEFAULT NULL,
                                                                        `product_name` mediumtext,
                                                                        `breadcrumb` mediumtext,
                                                                        `cat1` mediumtext,
                                                                        `cat2` mediumtext,
                                                                        `cat3` mediumtext,
                                                                        `cat4` mediumtext,
                                                                        `cat5` mediumtext,
                                                                        `url` mediumtext,
                                                                        `images` mediumtext,
                                                                        `video` mediumtext,
                                                                        `base_vkp` varchar(100) DEFAULT NULL,
                                                                        `price_vkp_no_discount` varchar(100) DEFAULT NULL,
                                                                        `discount_absolute` varchar(100) DEFAULT NULL,
                                                                        `discount_percent` varchar(100) DEFAULT NULL,
                                                                        `rrp` varchar(100) DEFAULT NULL,
                                                                        `vat` varchar(100) DEFAULT NULL,
                                                                        `price_relay` varchar(100) DEFAULT NULL,
                                                                        `delivery_cost` varchar(50) DEFAULT NULL,
                                                                        `base_price` varchar(100) DEFAULT NULL,
                                                                        `price_unit_type` varchar(100) DEFAULT NULL,
                                                                        `price_unit_measure` varchar(100) DEFAULT NULL,
                                                                        `available_online` varchar(100) DEFAULT NULL,
                                                                        `click_collect` varchar(100) DEFAULT NULL,
                                                                        `click_reserve` varchar(100) DEFAULT NULL,
                                                                        `delivery_time` varchar(100) DEFAULT NULL,
                                                                        `danger_goods` varchar(100) DEFAULT NULL,
                                                                        `danger_class` varchar(100) DEFAULT NULL,
                                                                        `danger_h` varchar(100) DEFAULT NULL,
                                                                        `danger_p` varchar(100) DEFAULT NULL,
                                                                        `danger_euh` varchar(100) DEFAULT NULL,
                                                                        `safety_data_sheet` varchar(100) DEFAULT NULL,
                                                                        `technical_data_sheets` varchar(100) DEFAULT NULL,
                                                                        `energy_class` varchar(100) DEFAULT NULL,
                                                                        `energy_scale` varchar(100) DEFAULT NULL,
                                                                        `energy_label` varchar(100) DEFAULT NULL,
                                                                        `eupd_data_sheet` varchar(100) DEFAULT NULL,
                                                                        `brand` varchar(100) DEFAULT NULL,
                                                                        `rating_aggregated` varchar(100) DEFAULT NULL,
                                                                        `rating_amount` varchar(100) DEFAULT NULL,
                                                                        `rating_answered` varchar(100) DEFAULT NULL,
                                                                        `rating_amount_help` varchar(100) DEFAULT NULL,
                                                                        `rating_amount_not_help` varchar(100) DEFAULT NULL,
                                                                        `rating_date_first` varchar(100) DEFAULT NULL,
                                                                        `rating_date_last` varchar(100) DEFAULT NULL,
                                                                        `rating_amount_valid` varchar(100) DEFAULT NULL,
                                                                        `description` mediumtext,
                                                                        `attributes` mediumtext,
                                                                        `up_selling` varchar(100) DEFAULT NULL,
                                                                        `cross_selling` varchar(100) DEFAULT NULL,
                                                                        `variant_is` varchar(500) DEFAULT NULL,
                                                                        `variant_has` varchar(500) DEFAULT NULL,
                                                                        `variant_has_article_number` varchar(500) DEFAULT NULL,
                                                                        `time_collected` varchar(500) DEFAULT NULL,
                                                                        `sku` varchar(50) DEFAULT NULL,
                                                                        `handler` varchar(500) DEFAULT NULL,
                                                                         PRIMARY KEY (`Id`)
                                                                        )ENGINE = MYISAM; """
            self.cursor.execute(create_table)
        except Exception as e:
            print(f'Error in creating {region} product table',e)
        return self.cursor, self.con, db_nam

    def update_item(self, item):
        if isinstance(item, HellwegItem):
            try:
                make_update_query = f'update `{db_data_table}` set '
                for key, value in item.items():
                    if isinstance(value, str):
                        make_update_query += key + "=" + '"' + value.replace('"', "’") + '"' + ","
                    else:
                        make_update_query += key + "=" + '"' + value + '"' + ","
                print(make_update_query)

                Id = item['Id']

                update_query = f'{make_update_query} where Id={Id}'.replace(', where Id=', ' where Id=')

                self.cursor.execute(update_query)
                self.con.commit()
                print(Fore.GREEN +f"|--------------------------------{Id} is  updated------------------------------------------|")
            except Exception as e:
                print(e)