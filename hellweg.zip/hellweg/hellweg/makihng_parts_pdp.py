import pymysql
import numpy as np
from hellweg.config import *
spider_name = "pdp"
part_count = 20

from datetime import datetime
table_date = datetime.now().strftime('%Y%m%d')

with open('E:\Parag_Mer\Working\hellweg\hellweg\lazada_parag.txt','r') as f:
    file = f.read()
file = file.split('\n')
db_name = file[0].replace('db_name = ', '')
region = file[0][-2:]


database = pymysql.connect(host=db_host, user=db_user, password=db_passwd, database=db_name)
cursor = database.cursor()

sql_query = f'''SELECT * FROM {db_data_table} where status='Pending' '''

cursor.execute(sql_query)
results = cursor.fetchall()
rows = len(results)
check = rows/int(part_count)
core_list = [column for column in results]
C_ids = []
for itm in core_list:
    id = itm[0]
    C_ids.append(id)
temp=0
l = len(C_ids)

# n = int(input("Enter the Part:"))
n = part_count
d = round(l/n)
x_ids =np.array_split(C_ids,n)


path = f'E:\Parag_Mer\Working\hellweg\hellweg\spiders\pdp_{region}.bat'
try:
    with open(path, 'r+') as f1:
        f1.truncate()
except Exception as  e:
    print(e)
with open(path, 'a') as f:
    f.write(f'taskkill /im pdp__{region}.exe')
    f.write('\n')
    f.close()

for parts in x_ids:
    with open(path, 'a') as f:
        f.write(f'start  pdp__{region} crawl {spider_name} -a region={region.lower()} -a feed=*** -a start={parts[0]} -a end={parts[-1]}')
        f.write('\n')
        f.close()