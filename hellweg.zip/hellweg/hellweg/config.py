import random
import requests

import os
from datetime import datetime
from colorama import Fore, init
init(autoreset=True, convert=True)
today_date = datetime.now().strftime('%Y_%m_%d')
db_host = '192.168.1.70'
db_user = 'root'
db_passwd = 'xbyte'

db_input_sku = f'input_sku'
db_data_table = f'productdata_{today_date}'
db_subcategory = f'subcategory_{today_date}'

def makehtml(region):
    HTMLs = f"G:\\Parag_Mer\\HTMLs\Hellweg_{region}\\{today_date}\\"
    csv = rf'{HTMLs}\csv'
    try:
        if not os.path.exists(HTMLs):
            os.makedirs(HTMLs)
        if not os.path.exists(csv):
            os.makedirs(csv)
    except Exception as e:
        print('exception in makedir config file error: ', e)
    return HTMLs, csv
def main_requests(url):
    with open(r'E:\Parag_Mer\Working\hellweg\hellweg\winndows_UserAgent.txt', 'r') as f:
        useragent = f.read()
        useragent = useragent.splitlines()
        useragent = random.choice(useragent)
    head = {
        'authority': 'www.hellweg.de',
        'method': 'GET',
        'path': '/',
        'scheme': 'https',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'cache-control': 'max-age=0',
        'cookie': '_dy_csc_ses=t; _dy_c_exps=; _dycnst=dg; _dyid=7957860749385966849; _dyfs=1670419249022; _dyjsession=af0a5028b485e4d124f281351369fc22; dy_fs_page=www.hellweg.de; _dy_geo=IN.AS.IN_GJ.IN_GJ_Ahmedabad; _dy_df_geo=India..Ahmedabad; _dy_toffset=-2; timezone=Asia/Calcutta; _dyid_server=7957860749385966849; hw_so=1; hellweg-market=37; swag-amazon-pay=activated; dtgsAllowGtmTracking=1; paypal-cookie-key=true; wishlist-enabled=1; SearchCollectorSession=hjxpn3p; emos_jcsid=AYTsvw1GDHXO*PoCfN_2eQFsThtxTb9M:t:1:0; _gcl_au=1.1.1648596685.1670419266; ecd_analytics=true; ecd_arp=true; google-analytics-enabled=1; _gid=GA1.2.299383035.1670419266; _fbp=fb.1.1670419266280.570422084; _pm3pc=1; pm_spots_861318=1,2,3; pm_counter_861318=130; session-=tql29g4dp0jh7ita0m8ig3r03r; csrf[frontend.wishlist.product.merge]=2e97a805d662d0d0de109375d988b.fMd-wkJl6B1VIPuT6wTTK3C4bmn0M4GG6YsdY0voWEM.G4YLuHQ6uXA9bc-g3EKwRQfuCFHNQtfsg-1-NwW_DAYJjk2wKzyYXjBjzw; csrf[frontend.wishlist.product.merge.pagelet]=266.QsRVQCyahQcm49YqucwPwuJv6M7tErqR9bTVWX2JhoA.d6IDNXvU52pS2rAY7ao7rLIIhZeXds_EpMfmERjHssgwlxF4ePbDNkGRtQ; csrf[frontend.account.login]=7f.oSfr0eOk24Jq9WILte7aezCMh7mbns3tSPEHyXiZwDM.lEDbtdT1rrcjxFZ4w4CqS0rbtuP23KeFfJMwhkjMpWbyHqCOlp3iu1qfDQ; csrf[frontend.store-api.proxy]=0.oCSv213gk4LgNK19VWxspGCE3OS2QBfKSxLMr5Sru9M.817Arg6H1sOod8UUMysg4Rbbr4_HCTq8CSCG7Ln_7JbMbsKXEa7lwI924A; _dy_ses_load_seq=48853%3A1670423346850; _dy_soct=1123381.1364865.1670423346; _dy_lu_ses=af0a5028b485e4d124f281351369fc22%3A1670423349615; _dycst=dk.m.c.ws.; emos_jcvid=AYTsvw1GDHXO*PoCfN_2eQFsThtxTb9M:1:0:0:0:true:1; _ga=GA1.2.450116258.1670419266; _ga_PN0N4FZ001=GS1.1.1670476258.3.0.1670476258.0.0.0; _dc_gtm_UA-13070836-1=1',
        'upgrade-insecure-requests': '1',
        'user-agent': useragent
    }
    main_req = requests.get(url=url,headers=head)
    return main_req