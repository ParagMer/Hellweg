import scrapy
from scrapy import Selector
from mymodules_new._common_ import c_replace
from hellweg.config import *
from hellweg.pipelines import *

class HellSpider(scrapy.Spider):
    name = 'hell'

    def __init__(self, start='', end='', region='', feed=''):
        self.start = start
        self.end = end
        self.region = region

    def start_requests(self):
        try:
            self.region = self.region.lower()

            self.HTMLs, self.csv = makehtml(region=self.region)
            self.cursor, self.con, self.db_nam = HellwegPipeline.makedatabase(self, region=self.region)

            select_query = f'select * from {db_input_sku} where status = "Pending"'
            self.cursor.execute(select_query)
            main_url = [column for column in self.cursor.fetchall()][0][1]

            filename = f'{self.region}.html'
            path = self.HTMLs + filename

            if os.path.exists(path):
                path = path.replace("/", "\\")
                path = path.replace("\\\\", "\\")
                yield scrapy.FormRequest(url=f'file:{path}', callback=self.parse)
            else:
                main_req = main_requests(url=main_url)
                res = main_req.text
                with open(path,'w',encoding='utf8') as f:
                    f.write(res)
                if os.path.getsize(path) < 6000:
                    os.remove(path)
                yield scrapy.FormRequest(url=f'file:{path}', callback=self.parse)
        except Exception  as e:
            print('Error in start_request = ',e)
    def parse(self, response, **kwargs):
        try:
            #todo category
            all_category = response.xpath('//ul[@class="is-level-0"]/li/a/@href').getall()
            for i in all_category:
                try:
                    if 'https://www.hellweg.de' not in i:
                        i = 'https://www.hellweg.de' + i
                    i1 = i.split("/")[-2]
                    filename = f'{i1}_{self.region}.html'
                    path1 = self.HTMLs + filename
                    if os.path.exists(path1):
                        with open(path1, 'r',encoding='utf8') as f:
                            res1 = f.read()
                    else:
                        sub_category = main_requests(url=i)
                        res1 = sub_category.text
                        with open(path1, 'w', encoding='utf8') as f:
                            f.write(res1)
                        if os.path.getsize(path1) < 6000:
                            os.remove(path1)
                    sc1 = Selector(text=res1)
                    all_sub_category = sc1.xpath('//a[@class="category-navigation-link"]/@href').getall()
                except Exception as e:
                    print('Error in first for loop = ',e)
                for j in all_sub_category:
                    try:
                        if 'https://www.hellweg.de' not in j:
                            j = 'https://www.hellweg.de' + j
                        j1 = j.split("/")[-2]
                        filename = f'{i1}_{j1}_{self.region}.html'
                        path2 = self.HTMLs + filename
                        if os.path.exists(path2):
                            with open(path2, 'r', encoding='utf8') as f:
                                res2 = f.read()
                        else:
                            sub_category = main_requests(url=j)
                            res2 = sub_category.text
                            with open(path2, 'w', encoding='utf8') as f:
                                f.write(res2)
                            if os.path.getsize(path2) < 6000:
                                os.remove(path2)
                        sc2 = Selector(text=res2)
                    except Exception as e:
                        print('Error in second for loop = ', e)
                    all_sub_sub_category = sc2.xpath('//ul[@class="category-navigation level-0"]//a/@href').getall()
                    total_count = sc2.xpath('//ul[@class="category-navigation level-0"]//a/span/text()').getall()
                    total_count = c_replace(total_count)
                    if not all_sub_sub_category == []:
                        for p in all_sub_sub_category:
                            try:
                                if 'https://www.hellweg.de' not in p:
                                    p = 'https://www.hellweg.de' + p
                                p1 = p.split("/")[-2]
                                insert_query = f'''insert into {db_subcategory} (category, Category_URL, SubCategory, SubCategoryURL, SubsubCategory, SubsubCategoryURL) VALUES ("{i1}", "{i}", "{j1}", "{j}", "{p1}", "{p}")'''
                                self.cursor.execute(insert_query)
                                self.con.commit()
                            except Exception as e:
                                print('Error in third for loop = ', e)
                    else:
                        print('')

            update_q = f'update {db_input_sku} set status = "Done" where status = "Pending"'
            self.cursor.execute(update_q)
            self.con.commit()
        except Exception as e:
            print('Error in Parse = ',e)
if __name__ == '__main__':
    from scrapy.cmdline import execute
    execute('scrap crawl hell -a region=at -a start=1 -a end=1'.split())