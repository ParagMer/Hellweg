import hashlib
from hellweg.pipelines import *

class HellSpider(scrapy.Spider):
    name = 'pl'

    def __init__(self, start='', end='', region='', feed=''):
        self.start = start
        self.end = end
        self.region = region

    def start_requests(self):
        try:
            self.region = self.region.lower()

            self.HTMLs, self.csv = makehtml(region=self.region)
            self.cursor, self.con, self.db_nam = HellwegPipeline.makedatabase(self, region=self.region)

            select_query = f'select id, SubsubCategoryURL from {db_subcategory} where status = "Pending" and id between {self.start} and {self.end}'
            self.cursor.execute(select_query)
            table = self.cursor.fetchall()
            page_count = 1
            for row in table:
                id = row[0]
                subsubCategoryURL = row[1]
                hash_object = hashlib.md5(subsubCategoryURL.encode())
                sub_hex_dig = hash_object.hexdigest()
                filename = f'{sub_hex_dig}_{page_count}.html'
                path = self.HTMLs + filename
                meta_dict = {
                    'page_count': page_count,
                    'id': id,
                    'path': path,
                    'sub_hex_dig': sub_hex_dig,
                    'subsubCategoryURL': subsubCategoryURL
                }
                if os.path.exists(path):
                    path = path.replace("/", "\\")
                    path = path.replace("\\\\", "\\")
                    yield scrapy.Request(url=f'file:{path}', dont_filter=True, callback=self.parse, meta={"meta_dict": meta_dict, 'dont_merge_cookies': True})
                else:
                    main_req = main_requests(url=subsubCategoryURL)
                    res = main_req.text
                    with open(path,'w',encoding='utf8') as f:
                        f.write(res)
                    if os.path.getsize(path) < 6000:
                        os.remove(path)
                    yield scrapy.Request(url=f'file:{path}', dont_filter=True, callback=self.parse, meta={"meta_dict": meta_dict, 'dont_merge_cookies': True})

        except Exception  as e:
            print('Error in start_request = ', e)

    def parse(self, response, **kwargs):
        #todo
        meta = response.meta.get('meta_dict')
        page_count = meta.get('page_count')
        id = meta.get('id')
        path = meta.get('path')
        sub_hex_dig = meta.get('sub_hex_dig')
        subsubCategoryURL = meta.get('subsubCategoryURL')
        pdp_url = response.xpath('//div[@class="row cms-listing-row js-listing-wrapper"]//div[@class="product-image-wrapper"]/a/@href').getall()
        rank = 0
        for i in pdp_url:
            rank += 1
            insert_q = f'''insert into {db_data_table} (url, id1, rank, HTML_PL_Path) VALUES ("{i}", "{id}","{rank}","{path}")'''
            self.cursor.execute(insert_q)
            self.con.commit()
            print(Fore.GREEN + '!!!!!!!!!!!!!!!!!!!!!!!!!Inserted Sucessfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')

        page_count += 1
        filename = f'{sub_hex_dig}_{page_count}.html'
        next_path = self.HTMLs + filename
        meta_dict = {'page_count': page_count, 'sub_hex_dig': sub_hex_dig, 'subsubCategoryURL': subsubCategoryURL, 'id': id}

        if os.path.exists(next_path):
            path = path.replace("/", "\\")
            path = path.replace("\\\\", "\\")
            yield scrapy.Request(url=f'file:{next_path}', dont_filter=True , callback=self.parse, meta={"meta_dict": meta_dict, 'dont_merge_cookies': True})
        else:
            next_page_url = f'{subsubCategoryURL}?order=topseller&p={page_count}'
            main_req = main_requests(url=next_page_url)
            res = main_req.text
            if 'Keine Produkte gefunden' in res:
                update_q = f'update {db_subcategory} set status="Done" where id = {id}'
                self.cursor.execute(update_q)
                self.con.commit()
                return None

            with open(next_path, 'w', encoding='utf8') as f:
                f.write(res)
            if os.path.getsize(next_path) < 6000:
                os.remove(next_path)
            yield scrapy.Request(url=f'file:{next_path}', dont_filter=True, callback=self.parse,meta={"meta_dict": meta_dict, 'dont_merge_cookies': True})

if __name__ == '__main__':
    from scrapy.cmdline import execute
    execute('scrap crawl pl -a region=de -a start=6 -a end=156'.split())