import json
import re

import pandas as pd
from mymodules_new._common_ import c_replace
from hellweg.pipelines import *
from hellweg.items import *

class HellSpider(scrapy.Spider):
    name = 'pdp'

    def __init__(self, start='', end='', region='', feed=''):
        self.start = start
        self.end = end
        self.region = region

    def start_requests(self):
        try:
            self.region = self.region.lower()

            self.HTMLs, self.csv = makehtml(region=self.region)
            self.cursor, self.con, self.db_nam = HellwegPipeline.makedatabase(self, region=self.region)

            select_query = f'select id, url from {db_data_table} where status = "Pending" and id between {self.start} and {self.end}'
            self.cursor.execute(select_query)
            table = self.cursor.fetchall()
            for row in table:
                id = row[0]
                url = row[1]
                filename = f'page_{id}.html'
                path = self.HTMLs + filename
                meta_dict = {
                    'id': id,
                    'path': path,
                }
                if os.path.exists(path):
                    # path = path.replace("/", "\\")
                    path = path.replace("\\\\", "\\")
                    yield scrapy.Request(url=f'file:{path}', dont_filter=True, callback=self.parse, meta={"meta_dict": meta_dict, 'dont_merge_cookies': True})
                else:
                    main_req = main_requests(url=url)
                    res = main_req.text
                    with open(path, 'w', encoding='utf8') as f:
                        f.write(res)
                    if os.path.getsize(path) < 6000:
                        os.remove(path)
                    yield scrapy.Request(url=f'file:{path}', dont_filter=True, callback=self.parse, meta={"meta_dict": meta_dict, 'dont_merge_cookies': True})

        except Exception  as e:
            print('Error in start_request = ',e)

    def parse(self, response, **kwargs):
        meta = response.meta.get('meta_dict')
        id = meta.get('id')
        path = meta.get('path')
        item = HellwegItem()

        #todo category, sub_category, sub_sub_category
        try:
            category = response.xpath('//ol[@class="breadcrumb"]//span[@class="breadcrumb-title"]/text()').getall()
            if category:
                catego = category[1]
                sub_category = category[2]
                sub_sub_category = category[3]
                cat1 = category[0]
                item['cat1'] = c_replace(str(cat1))
                item['cat2'] = c_replace(str(catego))
                item['cat3'] = c_replace(str(sub_category))
                item['cat4'] = c_replace(str(sub_sub_category))
                item['category'] = c_replace(str(catego))
                item['subcategory'] = c_replace(str(sub_category))
                item['subsubcategory'] = c_replace(str(sub_sub_category))
            else:
                item['cat1'] = 'NA'
                item['cat2'] = 'NA'
                item['cat3'] = 'NA'
                item['cat4'] = 'NA'
                item['category'] = 'NA'
                item['subcategory'] = 'NA'
                item['subsubcategory'] = 'NA'
        except Exception as e:
            print('Error in Category = ', e)

        #todo article_number
        article_number = ''
        try:
            article_number = response.xpath('//span[@itemprop="sku"]/text()').get()
            if article_number:
                article_number = c_replace(str(article_number))
            else:
                article_number = 'NA'
            item['article_number'] = article_number
            item['up_selling'] = article_number
            item['cross_selling'] = article_number
        except Exception as e:
            print('Error in article_number = ', e)

        #todo product_name
        try:
            product_name = response.xpath('//h1/text()').get()
            if product_name:
                product_name = c_replace(str(product_name))
            else:
                product_name = 'NA'
            item['product_name'] = product_name
        except Exception as e:
            print('Error in product_name = ', e)

        #todo images
        try:
            images = response.xpath('//div[@class="gallery-slider-thumbnails-container is-underneath"]//div[@class="gallery-slider-thumbnails-item-inner"]//img/@src').getall()
            if images:
                images = c_replace(images)
                images = ' #||# '.join(images)
            else:
                images = response.xpath('//div[@class="cms-element-"]//img/@src').get()
                if images:
                    images = c_replace(images)
                else:
                    images = 'NA'
            item['images'] = images
        except Exception as e:
            print('Error in images = ', e)

        #todo breadcrumb
        try:
            breadcrumb = response.xpath('//ol[@class="breadcrumb"]//span[@class="breadcrumb-title"]/text()').getall()
            if breadcrumb:
                breadcrumb = ' > '.join(breadcrumb)
            else:
                breadcrumb = 'NA'
            item['breadcrumb'] = breadcrumb
        except Exception as e:
            print('Error in breadcrumb = ', e)

        #todo price
        try:
            price = response.xpath('//div[@class="product-detail-price-wrapper"]/p/text()').getall()
            if price:
                price = ''.join(price)
                price = c_replace(price)
                price = re.findall("\d", price)
                price = ''.join(price)
            else:
                price = 'NA'
            item['base_vkp'] = price
        except Exception as e:
            print('Error in price = ', e)

        #todo price_vkp_no_discount
        try:
            price_vkp_no_discount = response.xpath('//span[@class="list-price-price"]/text()').getall()
            if price_vkp_no_discount:
                price_vkp_no_discount = ''.join(price_vkp_no_discount)
                price_vkp_no_discount = c_replace(price_vkp_no_discount)
                price_vkp_no_discount = re.findall("\d", price_vkp_no_discount)
                price_vkp_no_discount = ''.join(price_vkp_no_discount)
            else:
                price_vkp_no_discount = 'NA'
            item['price_vkp_no_discount'] = price_vkp_no_discount
        except Exception as e:
            print('Error in price_vkp_no_discount = ', e)

        #todo delivery_cost
        try:
            delivery_cost = response.xpath('//span[contains(text(),"Versandkosten")]/text()').get()
            if delivery_cost:
                delivery_cost = c_replace(delivery_cost)
                delivery_cost = re.findall("\d", delivery_cost)
                delivery_cost = ''.join(delivery_cost)
            else:
                delivery_cost = 'NA'
            item['delivery_cost'] = delivery_cost
        except Exception as e:
            print('Error in delivery_cost = ', e)

        #todo price_unit_type
        try:
            price_unit_type = response.xpath('//span[contains(text(),"Inhalt:")]/following-sibling::span/text()').get()
            if price_unit_type:
                price_unit_type = c_replace(str(price_unit_type))
            else:
                price_unit_type = 'NA'
            item['price_unit_type'] = price_unit_type
        except Exception as e:
            print('Error in price_unit_type = ', e)

        #todo delivery_time
        try:
            delivery_time = response.xpath('//span[@class="shipping-availability-time"]/text()').get()
            if delivery_time:
                delivery_time = c_replace(delivery_time)
                delivery_time = delivery_time.replace('Speditionsversand:', '')
            else:
                delivery_time = 'NA'
            item['delivery_time'] = delivery_time
        except Exception as e:
            print('Error in delivery_time = ', e)


        #todo EAN
        try:
            ean = response.xpath('//meta[@itemprop="gtin13"]/@content').get()
            if ean:
                ean = c_replace(ean)
            else:
                ean = 'NA'
            item['ean'] = ean
        except Exception as e:
            print('Error in ean = ', e)

        #todo Store_Selected
        try:
            store_Selected = response.xpath('//strong[contains(text(),"Markt:")]/span/text()').getall()
            if store_Selected:
                store_Selected = c_replace(store_Selected)
            else:
                store_Selected = 'NA'
            item['Store_Selected'] = store_Selected
        except Exception as e:
            print('Error in Store_Selected = ', e)

        # todo VAT
        try:
            vat = response.xpath('//a[@class="product-detail-tax-link"]/text()').get()
            if vat:
                vat = c_replace(vat)
                vat = vat.split(' ')[2:4]
                vat = ''.join(vat)
            else:
                vat = 'NA'
            item['vat'] = c_replace(str(vat))
        except Exception as e:
            print('Error in vat = ', e)

        # todo available_online, click_collect
        try:
            url = f'https://www.hellweg.de/market/37/stock/{article_number}/1'
            filename = f'page_{id}_{article_number}.html'
            path1 = self.HTMLs + filename
            if os.path.exists(path1):
                with open(path1, 'r', encoding='utf8') as f:
                    pa = f.read()
            else:
                paa = main_requests(url=url)
                pa = paa.text
                with open(path1, 'w', encoding='utf8') as f:
                    f.write(pa)
            j_data = json.loads(pa)
            available_online = j_data['shipping']['available']
            if available_online is True:
                item['available_online'] = 'True'
                item['click_collect'] = 'True'
            else:
                item['available_online'] = 'False'
                item['click_collect'] = 'False'
        except Exception as e:
            print('Error in available_online or click_collect = ', e)

        # todo brand
        try:
            brand = response.xpath('//a[@class="product-detail-manufacturer-link"]/@title').get()
            if brand:
                brand = brand
            else:
                brand = 'NA'
            item['brand'] = c_replace(str(brand))
        except Exception as e:
            print('Error in brand = ', e)

        # todo description
        try:
            description = response.xpath('//div[@class="product-detail-description-text"]/text()').get()
            if description:
                description = c_replace(description)
            else:
                description = 'NA'
            item['description'] = c_replace(str(description))
        except Exception as e:
            print('Error in description = ', e)

        # todo attributes
        try:
            attributes_dt = response.xpath('//div[@class="product-detail-properties"]//dt[@class="properties-label"]//text()').getall()
            attributes_dd = response.xpath('//div[@class="product-detail-properties"]//dd//text()').getall()
            if attributes_dt:
                attributes_dt = c_replace(attributes_dt)
                attributes_dd = c_replace(attributes_dd)
                res = {}
                for key in attributes_dt:
                    for value in attributes_dd:
                        res[key] = value
                        attributes_dd.remove(value)
                        break
                res = str(list(res.items()))
            else:
                res = 'NA'
            item['attributes'] = str(res)
        except Exception as e:
            print('Error in attributes = ', e)



        d = datetime.today().strftime("%Y/%d/%mT%H:%M:%SZ")
        item['HTML_PDP_Path'] = path
        item['discount_absolute'] = 'NA'
        item['energy_class'] = 'NA'
        item['energy_scale'] = 'NA'
        item['energy_label'] = 'NA'
        item['eupd_data_sheet'] = 'NA'
        item['variant_has_article_number'] = 'NA'
        item['time_collected'] = d
        item['variant_is'] = 'NA'
        item['variant_has'] = 'NA'
        item['rating_aggregated'] = 'NA'
        item['rating_amount'] = 'NA'
        item['rating_answered'] = 'NA'
        item['rating_amount_help'] = 'NA'
        item['rating_amount_not_help'] = 'NA'
        item['rating_date_first'] = 'NA'
        item['rating_date_last'] = 'NA'
        item['rating_amount_valid'] = 'NA'
        item['danger_goods'] = 'NA'
        item['danger_class'] = 'NA'
        item['danger_h'] = 'NA'
        item['danger_p'] = 'NA'
        item['danger_euh'] = 'NA'
        item['safety_data_sheet'] = 'NA'
        item['technical_data_sheets'] = 'NA'
        item['price_unit_measure'] = 'DE'
        item['click_reserve'] = 'TRUE'
        item['base_price'] = 'NA'
        item['discount_percent'] = 'NA'
        item['rrp'] = 'NA'
        item['price_relay'] = 'NA'
        item['video'] = 'False'
        item['shop_domain'] = f'hellweg.{self.region.lower()}'
        item['Status'] = 'Done'
        item['Id'] = str(id)
        HellwegPipeline.update_item(self, item)

    def close(self):
        try:
            prod_sql = f"SELECT * FROM {db_data_table} WHERE status='Pending'"
            cursor = self.cursor.execute(prod_sql)
            if cursor == 0:
                print('spider is close,...................')
                print('going on QA and make csv..............')
                try:
                    Csv_Output_File_Path = self.csv
                    print(Csv_Output_File_Path)
                    try:
                        if not os.path.exists(Csv_Output_File_Path):
                            os.makedirs(Csv_Output_File_Path)
                    except:
                        pass

                    sql_query = pd.read_sql_query(f'select `ean`, `shop_domain`,`store_selected`,`article_number`,`product_name`,`breadcrumb`,`cat1`,`cat2`,`cat3`,`cat4`,`cat5`,`url`,`images`,`video`,`base_vkp`,`price_vkp_no_discount`,`discount_absolute`,`discount_percent`,`rrp`,`vat`,`price_relay`,`base_price`,`price_unit_type`,`price_unit_measure`,`available_online`,`click_collect`,`click_reserve`,`delivery_time`,`danger_goods`,`danger_class`,`danger_h`,`danger_p`,`danger_euh`,`safety_data_sheet`,`technical_data_sheets`,`energy_class`,`energy_scale`,`energy_label`,`eupd_data_sheet`,`brand`,`rating_aggregated`,`rating_amount`,`rating_answered`,`rating_amount_help`,`rating_amount_not_help`,`rating_date_first`,`rating_date_last`,`rating_amount_valid`,`description`,`attributes`,`up_selling`,`cross_selling`,`variant_is`,`variant_has`,`variant_has_article_number`,`time_collected` from {db_data_table} where status!="Pending"  Group BY ean', self.con)
                    print(sql_query)
                    df = pd.DataFrame(sql_query)
                    df.to_csv(f'{Csv_Output_File_Path}/Hellwag_{self.region}_{today_date}.csv', index=False,encoding='utf-8-sig')
                    df.to_excel(f'{Csv_Output_File_Path}/Hellwag_{self.region}_{today_date}.xlsx', index=False, encoding='utf-8-sig')
                    print(f"csv path = {Csv_Output_File_Path}/Hellwag_{self.region}_{today_date}")
                except Exception as e:
                    print("ERROR", e)

            else:
                print('some entries are pending')
        except Exception as e:
            print(e)


if __name__ == '__main__':
    from scrapy.cmdline import execute
    execute('scrap crawl pdp -a region=de -a start=1 -a end=1'.split())